### 程序员简历模板
一个简洁使用的程序员简历模板，感谢 [Trinea](https://github.com/Trinea) 的指导——[推荐两个技术简历模板](http://b.codekk.com/detail/Trinea/%E6%8E%A8%E8%8D%90%E4%B8%A4%E4%B8%AA%E6%8A%80%E6%9C%AF%E7%AE%80%E5%8E%86%E6%A8%A1%E6%9D%BF)

这份简历看起来的是这个样子：

![Programmer's resume](snapshot.png)

希望对找工作的你有所帮助 :)